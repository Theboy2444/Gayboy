from django.shortcuts import render
from .exchanges import get_binance_price, get_kucoin_price, get_bybit_price

def home(request):
    binance = get_binance_price()
    kucoin = get_kucoin_price()
    bybit = get_bybit_price()

    prices = {
        "Binance": binance,
        "KuCoin": kucoin,
        "Bybit": bybit,
    }

    # Calculate arbitrage
    min_ex = min(prices, key=prices.get)
    max_ex = max(prices, key=prices.get)
    profit = prices[max_ex] - prices[min_ex] if prices[min_ex] and prices[max_ex] else 0

    context = {
        "prices": prices,
        "opportunity": {
            "buy_from": min_ex,
            "sell_to": max_ex,
            "profit": round(profit, 2)
        } if profit > 0 else None
    }
    return render(request, "home.html", context)
