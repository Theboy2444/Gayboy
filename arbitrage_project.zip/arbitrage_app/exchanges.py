import requests

def get_binance_price(symbol="BTCUSDT"):
    try:
        url = f"https://api.binance.com/api/v3/ticker/price?symbol={symbol}"
        res = requests.get(url).json()
        return float(res["price"])
    except Exception as e:
        return None

def get_kucoin_price(symbol="BTC-USDT"):
    try:
        url = f"https://api.kucoin.com/api/v1/market/orderbook/level1?symbol={symbol}"
        res = requests.get(url).json()
        return float(res["data"]["price"])
    except Exception as e:
        return None

def get_bybit_price(symbol="BTCUSDT"):
    try:
        url = f"https://api.bybit.com/v2/public/tickers?symbol={symbol}"
        res = requests.get(url).json()
        return float(res["result"][0]["last_price"])
    except Exception as e:
        return None
